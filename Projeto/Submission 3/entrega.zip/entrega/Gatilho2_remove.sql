Drop Trigger T2;
