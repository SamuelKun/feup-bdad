.read criar.sql
.read povoar.sql

Select * from Compoe;

.print "\nTentativa de adicionar um album de 1991 aos Paramore, uma banda fundada em 2004"
insert into Compoe values (5,1);

.print "\nAdicionou-se aos Paramore um Album de 2017\n"

insert into Compoe values (5,10);

Select * from Compoe;
.print "\nSucesso ao adicionar novo album aos Paramore!!"
