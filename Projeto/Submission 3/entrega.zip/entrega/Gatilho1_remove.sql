Drop trigger T1;
