.read criar.sql
.read povoar.sql

Select * from TempoOuvido
Order By idSessao
Limit 5;

Insert into TempoOuvido Values (1,1,12);

Select * from TempoOuvido
Order By idSessao
Limit 5;

.print "\nDuração do primeiro tuplo incrementou por 12 em vez de adicionar um novo tuplo"