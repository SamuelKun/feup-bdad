Drop Trigger T3;
